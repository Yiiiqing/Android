package com.example.grocerylist.Activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.grocerylist.Data.DatabaseHandler;
import com.example.grocerylist.Model.Grocery;
import com.example.grocerylist.R;
import com.example.grocerylist.UI.RecyclerViewAdapter;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

public class ListActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerViewAdapter recyclerViewAdapter;
    private List<Grocery> groceryList;
    private List<Grocery> listItems;
    private DatabaseHandler db;
    private AlertDialog.Builder alertdialogbuilder;
    private AlertDialog dialog;
    private LayoutInflater inflater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);


        db = new DatabaseHandler(this);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerViewID);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));// context of recyclerview

        groceryList = new ArrayList<>();
        listItems = new ArrayList<>();

        //Get items from datebase;
        groceryList = db.getAllGroceries();

        for(Grocery c : groceryList){
            Grocery grocery = new Grocery();
            grocery.setName(c.getName());
            grocery.setQuantity("Qty: " + c.getQuantity());
            grocery.setId(c.getId());
            grocery.setDateItemAdded("Added on: " + c.getDateItemAdded());

            listItems.add(grocery);
        }

        recyclerViewAdapter = new RecyclerViewAdapter(this,listItems);
        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerViewAdapter.notifyDataSetChanged();


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                Log.d("press","press the fab");
                alertdialogbuilder = new AlertDialog.Builder(ListActivity.this);
                inflater = LayoutInflater.from(ListActivity.this);

                final View popview = inflater.inflate(R.layout.popup,null);


                //TODO: ask qustion!!!!

                alertdialogbuilder.setView(popview);
                dialog = alertdialogbuilder.create();
                dialog.show();
                //setContentView(R.layout);
                Button saveButton = (Button) dialog.findViewById(R.id.saveButtonID);
                final TextView groceryName = (TextView) dialog.findViewById(R.id.grocery_item);
                final TextView quantity = (TextView) dialog.findViewById(R.id.grocery_Qty);
                //addItem();
                saveButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.d("click", "click save button");
                        if(!groceryName.getText().toString().isEmpty() && !quantity.getText().toString().isEmpty()){
                            Grocery grocery = new Grocery();
                            grocery.setName(groceryName.getText().toString());
                            grocery.setQuantity(quantity.getText().toString());

                            db.addGrocery(grocery);
                            Snackbar.make(popview,"Save to DB", Snackbar.LENGTH_LONG).show();


                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    dialog.dismiss();
                                    //refresh RecyclerView
                                    Intent intent = new Intent(ListActivity.this,ListActivity.class);
                                    startActivity(intent);
                                }
                            },1000);
                        }else{
                            Snackbar.make(popview,"Enter full information", Snackbar.LENGTH_LONG).show();
                        }
                    }



                });

            }
        });

    }




}
