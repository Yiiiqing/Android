package com.example.moviedirectory.Util;

public class Constants {

    public static final String URL_LEFT = "http://www.omdbapi.com/?s=";
    public static final String URL = "http://www.omdbapi.com/?i=";
    public static final String URL_RIGHT = "&page=2";
}
